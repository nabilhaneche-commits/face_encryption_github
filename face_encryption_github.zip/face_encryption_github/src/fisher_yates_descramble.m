function arr = fisher_yates_descramble(C1, Z)
% FISHER_YATES_DESCRAMBLE  Reverses the hyperchaotic Fisher-Yates permutation.
%
%   arr = FISHER_YATES_DESCRAMBLE(C1, Z)
%
%   C1 : 1-by-n permuted array
%   Z  : 1-by-n uint32 hyperchaotic keystream (same as used for scrambling)
%
%   Returns arr, the original (un-permuted) array.
%
%   The inverse is obtained by traversing the swap sequence in forward order
%   (i = 2 to n) and re-applying each swap.

    arr = C1;
    n   = numel(arr);

    for i = 2 : n
        j = mod(double(Z(i-1)), i) + 1;
        tmp    = arr(i);
        arr(i) = arr(j);
        arr(j) = tmp;
    end
end
