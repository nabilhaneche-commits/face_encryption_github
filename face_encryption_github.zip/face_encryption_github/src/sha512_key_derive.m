function [x0, y0, z0, x1, y1, z1] = sha512_key_derive(P)
% SHA512_KEY_DERIVE  Derives two sets of initial conditions from SHA-512
%   digests of the face sub-image and the full plaintext image.
%
%   [x0,y0,z0, x1,y1,z1] = SHA512_KEY_DERIVE(P)
%
%   Inputs
%   ------
%     P : uint8 RGB plaintext image (M x N x 3)
%
%   Outputs
%   -------
%     x0, y0, z0 : initial conditions for the face-region hyperchaotic run
%     x1, y1, z1 : initial conditions for the full-image hyperchaotic run
%
%   Key-derivation procedure (Section 3.3.1 of the paper):
%     1. Compute SHA-512 of the byte stream of P -> 128 hex characters H.
%     2. Split H into 8 equal 16-character hex segments.
%     3. Convert each segment to its decimal value: K1 ... K8.
%     4. x = (K1+K2+K3)/3,  y = (K4+K5+K6)/3,  z = (K7+K8)/2.
%
%   The face-region key uses the face sub-image (detected via Haar cascade)
%   and the full-image key uses the complete image P.

    % ── Helper: derive (x,y,z) from one image ────────────────────────────────
    derive = @(img) derive_keys(img);

    % Face sub-image
    [P1, ~] = detect_face(P);
    [x0, y0, z0] = derive(P1);

    % Full image
    [x1, y1, z1] = derive(P);
end

% ─────────────────────────────────────────────────────────────────────────────
function [x, y, z] = derive_keys(img)
% Computes SHA-512 of img and derives (x, y, z).

    img_bytes = img(:);                     % column vector of uint8

    % Compute SHA-512 using Java's MessageDigest (available in MATLAB)
    import java.security.MessageDigest;
    import java.math.BigInteger;
    md   = MessageDigest.getInstance('SHA-512');
    hash = md.digest(img_bytes);            % 64 signed bytes (Java)

    % Convert to 128-character lowercase hex string
    hex_str = sprintf('%02x', typecast(int8(hash), 'uint8'));

    % Split into 8 segments of 16 hex chars each
    K = zeros(1, 8);
    for k = 1:8
        seg  = hex_str( (k-1)*16+1 : k*16 );
        K(k) = hex2dec_safe(seg);
    end

    % Derive initial conditions
    x = (K(1) + K(2) + K(3)) / 3;
    y = (K(4) + K(5) + K(6)) / 3;
    z = (K(7) + K(8))        / 2;

    % Normalize to a bounded floating-point range suitable as ODE initial cond.
    scale = 1e-10;
    x = mod(x * scale, 10);
    y = mod(y * scale, 10);
    z = mod(z * scale, 10);
    if x == 0, x = 0.1; end
    if y == 0, y = 0.1; end
    if z == 0, z = 0.1; end
end

% ─────────────────────────────────────────────────────────────────────────────
function val = hex2dec_safe(hex_str)
% Converts a 16-char hex string to double without integer overflow.
% Uses Java BigInteger for large values.
    import java.math.BigInteger;
    bi  = BigInteger(hex_str, 16);
    val = double(bi);
end
