function C1 = fisher_yates_scramble(arr, Z)
% FISHER_YATES_SCRAMBLE  Hyperchaotic Fisher-Yates permutation.
%
%   C1 = FISHER_YATES_SCRAMBLE(arr, Z)
%
%   arr : 1-by-n uint8 (or numeric) array to be permuted
%   Z   : 1-by-n uint32 hyperchaotic keystream (from HYPERCHAOTIC_SEQUENCES)
%
%   Returns C1, the permuted array of the same size and type.
%
%   Algorithm (Section 3.2 of the paper, forward pass i = n down to 2):
%     For i = n, n-1, ..., 2:
%       j = mod(Z(i-1), i) + 1   (1-based index in [1, i])
%       swap arr(i) and arr(j)
%
%   The hyperchaotic sequence Z replaces the conventional PRNG, markedly
%   increasing the cryptographic unpredictability of the permutation.

    C1 = arr;
    n  = numel(C1);

    for i = n : -1 : 2
        j = mod(double(Z(i-1)), i) + 1;   % j in [1, i]
        tmp   = C1(i);
        C1(i) = C1(j);
        C1(j) = tmp;
    end
end
