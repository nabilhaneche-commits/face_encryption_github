function flat = s_curve_flatten(img)
% S_CURVE_FLATTEN  Serializes a 3-channel image into a 1-D array by
%   traversing each row alternately left-to-right and right-to-left
%   (S-curve / boustrophedon scan) for each channel in R, G, B order.
%
%   flat = S_CURVE_FLATTEN(img)
%
%   Input  : uint8 M x N x 3 image
%   Output : 1 x (3*M*N) uint8 row vector
%
%   The S-curve scan reads row i from left to right when i is odd and from
%   right to left when i is even, introducing a spatial mixing that breaks
%   horizontal pixel correlations before the XOR diffusion step.

    [M, N, ~] = size(img);
    flat = zeros(1, 3*M*N, 'uint8');
    ptr  = 1;

    for ch = 1:3
        for i = 1:M
            if mod(i, 2) == 1
                row = img(i, :, ch);            % left-to-right
            else
                row = img(i, end:-1:1, ch);     % right-to-left
            end
            flat(ptr : ptr+N-1) = row;
            ptr = ptr + N;
        end
    end
end
