function P_out = dna_undiffuse_channels(P_in)
% DNA_UNDIFFUSE_CHANNELS  Reverses the 12-bit DNA diffusion (Rule 1).
%
%   P_out = DNA_UNDIFFUSE_CHANNELS(P_in)
%
%   Input  : uint8 M x N x 3 DNA-diffused image
%   Output : uint8 M x N x 3 recovered image
%
%   Because the Watson-Crick complement is an involution (applying it twice
%   returns the original pair), the inverse of the DNA diffusion is obtained
%   by applying the SAME complement operation again on the 12-bit
%   representation of each diffused value and then rebuilding the original
%   decimal.
%
%   Inverse procedure for each diffused pixel value w in {0,...,255}:
%     1. Build a 12-bit binary array A from w in the same positional way
%        (hundreds, tens, units digits each to 4-bit words).
%     2. Apply Watson-Crick complement on each bit-pair -> B.
%     3. Reinterpret B: split into three 4-bit groups -> three decimal digits
%        -> reconstruct original value = hundreds*100 + tens*10 + units.
%
%   Note: because the forward diffusion applies the complement to the 12-bit
%   encoding of the original value's digits, the inverse must undo this by
%   re-complementing the digits of the diffused value and then decoding.

    P_out = zeros(size(P_in), 'uint8');
    for ch = 1:3
        channel       = double(P_in(:,:,ch));
        P_out(:,:,ch) = dna_undiffuse_single(channel);
    end
end

% ─────────────────────────────────────────────────────────────────────────────
function out = dna_undiffuse_single(channel)
% Reverses 12-bit DNA diffusion for a 2-D pixel array.

    [M, N] = size(channel);
    out    = zeros(M, N, 'uint8');

    for idx = 1 : M*N
        w = channel(idx);               % diffused pixel in [0,255]

        % Decompose w into digits
        d_hundreds = floor(w / 100);
        d_tens     = floor(mod(w, 100) / 10);
        d_units    = mod(w, 10);

        % 12-bit representation of diffused value
        A = [ dec2bin_4(d_hundreds) , dec2bin_4(d_tens) , dec2bin_4(d_units) ];

        % Reverse complement (involution -> same operation)
        B = zeros(1, 12);
        for p = 1 : 2 : 12
            B(p:p+1) = complement_pair(A(p:p+1));
        end

        % Recover three 4-bit groups and decode original decimal digits
        g1 = bi2de(B(1:4),  'left-msb');  % hundreds digit
        g2 = bi2de(B(5:8),  'left-msb');  % tens digit
        g3 = bi2de(B(9:12), 'left-msb');  % units digit

        orig = g1*100 + g2*10 + g3;
        out(idx) = uint8(mod(orig, 256));
    end
end

% ─────────────────────────────────────────────────────────────────────────────
function bits = dec2bin_4(d)
    bits = de2bi(d, 4, 'left-msb');
end

function out_pair = complement_pair(pair)
    b1 = pair(1);  b2 = pair(2);
    if     b1==0 && b2==0,  out_pair = [1 1];
    elseif b1==1 && b2==1,  out_pair = [0 0];
    elseif b1==0 && b2==1,  out_pair = [1 0];
    else,                   out_pair = [0 1];
    end
end
