%% DEMO_ENCRYPTION.m
%  End-to-end demonstration of the face-targeted hyperchaotic image
%  encryption scheme proposed in:
%
%    Haneche N. and Hamaizia T., "A novel 4D ReLU-memristive hyperchaotic
%    system: Hidden attractors, multistability, and transient chaos with
%    application to face recognition encryption,"
%    The Visual Computer (submitted 2024).
%
%  Prerequisites
%  -------------
%    - MATLAB R2021a or later
%    - Image Processing Toolbox
%    - Computer Vision Toolbox  (for Haar cascade face detection)
%    - Communications Toolbox   (de2bi / bi2de, used in DNA diffusion)
%
%  Usage
%  -----
%    Place a 256x256 (or larger) RGB face image in the data/ folder and
%    update IMAGE_PATH below, then run the script.

clear; clc; close all;

%% ── 0. Load test image ────────────────────────────────────────────────────
IMAGE_PATH = fullfile('..', 'data', 'face_test.png');   % <-- update if needed

if ~isfile(IMAGE_PATH)
    error(['Test image not found: ' IMAGE_PATH ...
           '\nPlease place a face image in the data/ folder.']);
end

P = imread(IMAGE_PATH);
P = imresize(P, [256, 256]);    % resize to 256x256 for consistency
if size(P, 3) == 1
    P = repmat(P, 1, 1, 3);     % convert grayscale to pseudo-RGB
end
P = uint8(P);

fprintf('Image loaded: %s  [%dx%dx%d]\n', IMAGE_PATH, size(P,1), size(P,2), size(P,3));

%% ── 1. Encryption ─────────────────────────────────────────────────────────
fprintf('\nEncrypting...\n');
tic;
C = encrypt_image(P);
t_enc = toc;
fprintf('Encryption time: %.4f s\n', t_enc);

%% ── 2. Decryption ─────────────────────────────────────────────────────────
fprintf('Decrypting...\n');
tic;
P_dec = decrypt_image(C, P);
t_dec = toc;
fprintf('Decryption time: %.4f s\n', t_dec);

%% ── 3. Verify correctness ─────────────────────────────────────────────────
err = max(abs(double(P_dec(:)) - double(P(:))));
fprintf('\nMax pixel error after decrypt: %d  (should be 0)\n', err);

%% ── 4. Security metrics ───────────────────────────────────────────────────
fprintf('\n--- Security Metrics ---\n');

% Information entropy
for ch = 1:3
    cname = 'RGB'; ch_str = cname(ch);
    h_p = entropy_channel(P(:,:,ch));
    h_c = entropy_channel(C(:,:,ch));
    fprintf('Shannon entropy  [%s]: plain=%.4f  cipher=%.4f\n', ch_str, h_p, h_c);
end

% Pixel correlation (horizontal, plain vs cipher)
fprintf('\nHorizontal pixel correlation (R channel):\n');
fprintf('  Plain : %.4f\n', pixel_corr(P(:,:,1)));
fprintf('  Cipher: %.4f\n', pixel_corr(C(:,:,1)));

% NPCR & UACI
P_mod        = P;
P_mod(1,1,1) = uint8(mod(double(P_mod(1,1,1)) + 1, 256));
C_mod        = encrypt_image(P_mod);
[npcr, uaci] = npcr_uaci(C, C_mod);
fprintf('\nNPCR = %.4f %%\n', npcr);
fprintf('UACI = %.4f %%\n', uaci);

%% ── 5. Visual results ─────────────────────────────────────────────────────
figure('Name', 'Face Encryption Demo', 'NumberTitle', 'off', ...
       'Position', [100 100 900 300]);

subplot(1, 3, 1); imshow(P);     title('Plaintext',  'FontWeight', 'bold');
subplot(1, 3, 2); imshow(C);     title('Ciphertext', 'FontWeight', 'bold');
subplot(1, 3, 3); imshow(P_dec); title('Decrypted',  'FontWeight', 'bold');

sgtitle('4D ReLU-Memristive Hyperchaotic Face Encryption');

% Save results
imwrite(C,     fullfile('..', 'results', 'ciphertext.png'));
imwrite(P_dec, fullfile('..', 'results', 'decrypted.png'));
fprintf('\nOutput images saved to results/\n');

%% ═══════════════════════════════════════════════════════════════════════════
%  Local helper functions
%  ═══════════════════════════════════════════════════════════════════════════

function h = entropy_channel(ch)
% Shannon entropy of one channel.
    ch = double(ch(:));
    counts = histcounts(ch, 0:256) + eps;
    p = counts / sum(counts);
    h = -sum(p .* log2(p));
end

function r = pixel_corr(ch)
% Horizontal adjacent-pixel correlation coefficient.
    ch  = double(ch);
    x   = ch(:, 1:end-1);  x = x(:);
    y   = ch(:, 2:end  );  y = y(:);
    r   = corr(x, y);
end

function [npcr, uaci] = npcr_uaci(C1, C2)
% Number of Pixels Change Rate and Unified Average Changing Intensity.
    D    = double(C1) ~= double(C2);
    npcr = 100 * sum(D(:)) / numel(D);
    uaci = 100 * mean(abs(double(C1(:)) - double(C2(:)))) / 255;
end
