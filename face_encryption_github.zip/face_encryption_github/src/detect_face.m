function [P1, F] = detect_face(P)
% DETECT_FACE  Detects the frontal face region in a color image using the
%   MATLAB Computer Vision Toolbox Haar Cascade Classifier.
%
%   [P1, F] = DETECT_FACE(P)
%
%   Input
%   -----
%     P  : uint8 M x N x 3 RGB color image
%
%   Outputs
%   -------
%     P1 : uint8 M0 x N0 x 3 face sub-image (RGB crop at the detected bbox)
%     F  : 1-by-4 double array [x, y, width, height] in pixel coordinates
%          (x,y) is the top-left corner of the bounding box.
%
%   The detector uses the standard pre-trained frontal face cascade model
%   shipped with MATLAB's Computer Vision Toolbox (vision.CascadeObjectDetector).
%   The input image is first converted to grayscale for detection; the
%   extracted sub-image P1 is taken from the original color image.
%
%   If no face is detected, the function falls back to using the entire image
%   as the face region and issues a warning.

    % Convert to grayscale for detection
    if size(P, 3) == 3
        gray = rgb2gray(P);
    else
        gray = P;
    end

    % Create and configure the Haar cascade detector
    detector = vision.CascadeObjectDetector();
    detector.MinSize         = [30 30];
    detector.MergeThreshold  = 4;

    bbox = step(detector, gray);   % returns Kx4 array of bounding boxes

    if isempty(bbox)
        warning('detect_face:noFaceFound', ...
            'No face detected. Using the entire image as the face region.');
        [M, N, ~] = size(P);
        F  = [1, 1, N, M];
        P1 = P;
        return;
    end

    % Select the largest bounding box if multiple faces detected
    [~, idx] = max(bbox(:,3) .* bbox(:,4));
    F = double(bbox(idx, :));       % [x, y, w, h]

    % Clamp to image boundaries
    [M, N, ~] = size(P);
    x1 = max(1, F(1));
    y1 = max(1, F(2));
    x2 = min(N, F(1) + F(3) - 1);
    y2 = min(M, F(2) + F(4) - 1);
    F  = [x1, y1, x2-x1+1, y2-y1+1];

    % Extract face sub-image (RGB)
    r  = F(2) : F(2)+F(4)-1;
    c  = F(1) : F(1)+F(3)-1;
    P1 = P(r, c, :);
end
