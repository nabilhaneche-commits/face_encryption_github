function P_out = inter_channel_obfuscate(P_flat, Z, M, N)
% INTER_CHANNEL_OBFUSCATE  Applies inter-channel obfuscation by cyclically
%   permuting R, G, B channel assignments pixel-by-pixel.
%
%   P_out = INTER_CHANNEL_OBFUSCATE(P_flat, Z, M, N)
%
%   P_flat : 1-by-(3*M*N) serialized pixel array (R block | G block | B block)
%   Z      : 1-by-(3*M*N) uint32 hyperchaotic keystream
%   M, N   : image dimensions
%
%   Returns P_out of the same size and type.
%
%   Procedure (Section 2.2 of the paper, inter-channel obfuscation step):
%     1. Build an index sequence of length 3*M*N from Z, mapping each
%        element to {0, 1, 2} via mod(Z, 3).
%     2. For each pixel position p in {1,...,M*N}:
%          idx = mod(Z(p), 3)
%          Apply cyclic channel permutation driven by idx:
%            idx=0 : [R,G,B] -> [R,G,B]  (identity)
%            idx=1 : [R,G,B] -> [B,R,G]
%            idx=2 : [R,G,B] -> [G,B,R]
%
%   This completely severs residual inter-channel correlation.

    nPix  = M * N;
    P_out = P_flat;

    R = double(P_flat(1       : nPix));
    G = double(P_flat(nPix+1  : 2*nPix));
    B = double(P_flat(2*nPix+1: 3*nPix));

    R_out = R;  G_out = G;  B_out = B;

    for p = 1 : nPix
        idx = mod(double(Z(p)), 3);
        r = R(p);  g = G(p);  b = B(p);
        switch idx
            case 0
                R_out(p) = r;  G_out(p) = g;  B_out(p) = b;
            case 1
                % [R,G,B] -> [B,R,G]
                R_out(p) = b;  G_out(p) = r;  B_out(p) = g;
            case 2
                % [R,G,B] -> [G,B,R]
                R_out(p) = g;  G_out(p) = b;  B_out(p) = r;
        end
    end

    P_out = [R_out , G_out , B_out];
    P_out = uint8(P_out);
end
