function P_out = inter_channel_deobfuscate(P_flat, Z, M, N)
% INTER_CHANNEL_DEOBFUSCATE  Reverses the inter-channel obfuscation.
%
%   P_out = INTER_CHANNEL_DEOBFUSCATE(P_flat, Z, M, N)
%
%   Applies the inverse cyclic permutation for each pixel:
%     idx=0 : identity            (inverse: identity)
%     idx=1 : [R,G,B]->[B,R,G]   (inverse: [R,G,B]->[G,B,R])  i.e. idx=2
%     idx=2 : [R,G,B]->[G,B,R]   (inverse: [R,G,B]->[B,R,G])  i.e. idx=1

    nPix  = M * N;

    R = double(P_flat(1       : nPix));
    G = double(P_flat(nPix+1  : 2*nPix));
    B = double(P_flat(2*nPix+1: 3*nPix));

    R_out = R;  G_out = G;  B_out = B;

    for p = 1 : nPix
        idx = mod(double(Z(p)), 3);
        r = R(p);  g = G(p);  b = B(p);
        switch idx
            case 0
                R_out(p) = r;  G_out(p) = g;  B_out(p) = b;
            case 1
                % Inverse of [R,G,B]->[B,R,G]  is  [R,G,B]->[G,B,R]
                R_out(p) = g;  G_out(p) = b;  B_out(p) = r;
            case 2
                % Inverse of [R,G,B]->[G,B,R]  is  [R,G,B]->[B,R,G]
                R_out(p) = b;  G_out(p) = r;  B_out(p) = g;
        end
    end

    P_out = uint8([R_out , G_out , B_out]);
end
