function P_out = dna_diffuse_channels(P_in)
% DNA_DIFFUSE_CHANNELS  Applies 12-bit DNA diffusion (Rule 1) channel-wise
%   to an RGB image.
%
%   P_out = DNA_DIFFUSE_CHANNELS(P_in)
%
%   Input  : uint8 M x N x 3 image
%   Output : uint8 M x N x 3 diffused image
%
%   DNA diffusion procedure (Section 3.1 of the paper):
%     For each pixel value v in {0,...,255}:
%       1. Build a 12-bit binary array A by converting the three decimal
%          digits (units, tens, hundreds) of v each to 4-bit binary.
%       2. Apply Watson-Crick complementary base pairing under Rule 1
%          on consecutive bit-pairs of A -> output 12-bit array B.
%       3. Convert B to decimal, reduce mod 256 -> diffused pixel value.
%
%   DNA Rule 1 (Table 1 in paper):
%     00 -> A,  11 -> T,  01 -> C,  10 -> G
%   Watson-Crick complements:
%     A <-> T  (00 <-> 11)
%     C <-> G  (01 <-> 10)
%
%   Therefore the complement map on 2-bit pairs is:
%     00  ->  11   (A -> T)
%     11  ->  00   (T -> A)
%     01  ->  10   (C -> G)
%     10  ->  01   (G -> C)

    P_out = zeros(size(P_in), 'uint8');
    for ch = 1:3
        channel       = double(P_in(:,:,ch));
        P_out(:,:,ch) = dna_diffuse_single(channel);
    end
end

% ─────────────────────────────────────────────────────────────────────────────
function out = dna_diffuse_single(channel)
% Applies 12-bit DNA diffusion to a 2-D array of pixel values in [0,255].

    [M, N] = size(channel);
    out    = zeros(M, N, 'uint8');

    for idx = 1 : M*N
        v = channel(idx);               % pixel value in [0,255]

        % Step 1: extract decimal digits (hundreds, tens, units)
        d_hundreds = floor(v / 100);
        d_tens     = floor(mod(v, 100) / 10);
        d_units    = mod(v, 10);

        % Convert each digit to 4-bit binary (MSB first)
        A = [ dec2bin_4(d_hundreds) , dec2bin_4(d_tens) , dec2bin_4(d_units) ];
        % A is a 1x12 array of 0s and 1s

        % Step 2: Watson-Crick complement on each consecutive bit-pair
        B = zeros(1, 12);
        for p = 1 : 2 : 12
            pair = A(p:p+1);            % 2-bit pair [b1 b2]
            B(p:p+1) = complement_pair(pair);
        end

        % Step 3: convert 12-bit B to decimal, mod 256
        val    = bin2dec( num2str(B, '%d') );
        out(idx) = uint8(mod(val, 256));
    end
end

% ─────────────────────────────────────────────────────────────────────────────
function bits = dec2bin_4(d)
% Converts a decimal digit (0-9) to a 4-element binary array [b3 b2 b1 b0].
    b = de2bi(d, 4, 'left-msb');
    bits = b;
end

% ─────────────────────────────────────────────────────────────────────────────
function out_pair = complement_pair(pair)
% Watson-Crick complement under DNA Rule 1.
%   00 (A) <-> 11 (T)
%   01 (C) <-> 10 (G)
    b1 = pair(1);  b2 = pair(2);
    if     b1==0 && b2==0,  out_pair = [1 1];   % A -> T
    elseif b1==1 && b2==1,  out_pair = [0 0];   % T -> A
    elseif b1==0 && b2==1,  out_pair = [1 0];   % C -> G
    else,                   out_pair = [0 1];   % G -> C
    end
end
