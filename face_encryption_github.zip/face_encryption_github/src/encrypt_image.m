function C = encrypt_image(P)
% ENCRYPT_IMAGE  Face-targeted color image encryption using the 4D
%                ReLU-memristive hyperchaotic system.
%
%   C = ENCRYPT_IMAGE(P)  encrypts the M-by-N-by-3 uint8 RGB image P
%   and returns the ciphertext image C of the same size.
%
%   Algorithm pipeline
%   ------------------
%     1. SHA-512 key derivation from P
%     2. Haar cascade face detection
%     3. Hyperchaotic sequence generation (face region + full image)
%     4. 12-bit DNA diffusion on face sub-image
%     5. S-curve flattening + XOR with hyperchaotic sequences -> P2
%     6. Reinsertion of encrypted face into full frame -> P3
%     7. Parity-switched global diffusion -> P4
%     8. Hyperchaotic Fisher-Yates permutation -> P5
%     9. Inter-channel obfuscation -> C
%
%   Reference:
%     Haneche N. and Hamaizia T., "A novel 4D ReLU-memristive hyperchaotic
%     system: Hidden attractors, multistability, and transient chaos with
%     application to face recognition encryption," The Visual Computer.
%
%   See also: DECRYPT_IMAGE, HYPERCHAOTIC_SYSTEM, DNA_DIFFUSION,
%             FISHER_YATES_SCRAMBLE, SHA512_KEY_DERIVE

    P = im2uint8(P);
    [M, N, ~] = size(P);

    %% ── Step 1 : Key derivation (face region) ──────────────────────────────
    [x0, y0, z0, x1, y1, z1] = sha512_key_derive(P);

    %% ── Step 2 : Face detection ─────────────────────────────────────────────
    [P1, F] = detect_face(P);           % P1 = uint8 face sub-image (M0xN0x3)
    M0 = size(P1, 1);  N0 = size(P1, 2);
    nFace = 3 * M0 * N0;
    nFull = 3 * M  * N;

    %% ── Step 3 : Hyperchaotic sequences ────────────────────────────────────
    %  Face sequences
    [X0, Y0, Z0] = hyperchaotic_sequences(x0, y0, z0, nFace);
    %  Full-image sequences
    [X1, Y1, Z1] = hyperchaotic_sequences(x1, y1, z1, nFull);

    %% ── Step 4 : 12-bit DNA diffusion on face region ───────────────────────
    P1_dna = dna_diffuse_channels(P1);  % returns uint8 M0xN0x3

    %% ── Step 5 : S-curve flattening + XOR combination ──────────────────────
    face_flat = s_curve_flatten(P1_dna);  % 1 x nFace uint8
    num_arr   = double(face_flat);

    P2 = uint8(mod( ...
        bitxor(uint32(num_arr), ...
               uint32(mod(uint64(Y0) .* uint64(X0), 256))) ...
        + uint32(mod(uint64(Z0) .* uint64(1:nFace), 256)), ...
        256));
    % Equivalent scalar form for each i:
    %   P2(i) = mod( num(i) XOR (Y0(i)*X0(i)) XOR (Z0(i)*i) , 256 )
    P2 = uint8(mod( ...
        bitxor( bitxor(uint32(num_arr), ...
                       uint32(mod(double(Y0) .* double(X0), 256))), ...
                       uint32(mod(double(Z0) .* (1:nFace), 256)) ), ...
        256));

    %% ── Step 6 : Reinsert encrypted face into full frame → P3 ─────────────
    P3 = P;
    face_restored = s_curve_unflatten(P2, M0, N0);  % M0xN0x3
    r = F(2) : F(2)+F(4)-1;
    c = F(1) : F(1)+F(3)-1;
    P3(r, c, :) = face_restored;

    %% ── Step 7 : Parity-switched global diffusion → P4 ────────────────────
    P4 = zeros(M, N, 3, 'uint8');
    P3d = double(P3);
    k = 1;
    for ch = 1:3
        for i = 1:M
            for j = 1:N
                x1k = double(X1(k));  y1k = double(Y1(k));
                pix = P3d(i, j, ch);
                if mod(x1k + y1k, 2) == 0
                    val = mod(bitxor(uint32(abs(x1k - y1k)), ...
                              bitxor(uint32(pix), uint32(i))), 256);
                else
                    val = mod(bitxor(uint32(x1k + y1k), ...
                              bitxor(uint32(pix), uint32(i))), 256);
                end
                P4(i, j, ch) = uint8(val);
                k = k + 1;
            end
        end
    end

    %% ── Step 8 : Hyperchaotic Fisher-Yates permutation → P5 ───────────────
    % Serialize P4 (R then G then B in column-major order)
    P5 = [P4(:,:,1)(:)' , P4(:,:,2)(:)' , P4(:,:,3)(:)'];
    P5 = fisher_yates_scramble(P5, Z1);

    %% ── Step 9 : Inter-channel obfuscation → C ─────────────────────────────
    P6 = inter_channel_obfuscate(P5, Z1, M, N);
    C  = reshape(P6, M, N, 3);
    C  = uint8(C);
end
