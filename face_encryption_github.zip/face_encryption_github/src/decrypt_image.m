function P_dec = decrypt_image(C, P_original)
% DECRYPT_IMAGE  Decrypts a ciphertext image produced by ENCRYPT_IMAGE.
%
%   P_dec = DECRYPT_IMAGE(C, P_original)
%
%   C          - uint8 ciphertext image (M x N x 3)
%   P_original - the original plaintext image, required only for SHA-512
%                key re-derivation (the decryption keys are identical to
%                the encryption keys and depend on the plaintext).
%
%   Returns the decrypted image P_dec (uint8, M x N x 3).
%
%   Reference:
%     Haneche N. and Hamaizia T., "A novel 4D ReLU-memristive hyperchaotic
%     system: Hidden attractors, multistability, and transient chaos with
%     application to face recognition encryption," The Visual Computer.

    C = im2uint8(C);
    P_original = im2uint8(P_original);
    [M, N, ~] = size(C);

    %% ── Key derivation (same as encryption) ────────────────────────────────
    [x0, y0, z0, x1, y1, z1] = sha512_key_derive(P_original);

    %% ── Face detection (same bounding box as encryption) ───────────────────
    [P1, F] = detect_face(P_original);
    M0 = size(P1, 1);  N0 = size(P1, 2);
    nFace = 3 * M0 * N0;
    nFull = 3 * M  * N;

    %% ── Re-generate hyperchaotic sequences ──────────────────────────────────
    [X0, Y0, Z0] = hyperchaotic_sequences(x0, y0, z0, nFace);
    [X1, Y1, Z1] = hyperchaotic_sequences(x1, y1, z1, nFull);

    %% ── Step 1 : Reverse inter-channel obfuscation ──────────────────────────
    C_flat = double(C(:));           % column-major serialization
    P7     = inter_channel_deobfuscate(C_flat', Z1, M, N);

    %% ── Step 2 : Reverse Fisher-Yates permutation ───────────────────────────
    P8_flat = fisher_yates_descramble(P7, Z1);

    %% ── Step 3 : Reconstruct three-channel image P8 ─────────────────────────
    nPix = M * N;
    R8 = reshape(P8_flat(1        : nPix),      M, N);
    G8 = reshape(P8_flat(nPix+1   : 2*nPix),    M, N);
    B8 = reshape(P8_flat(2*nPix+1 : 3*nPix),    M, N);
    P8 = cat(3, uint8(R8), uint8(G8), uint8(B8));

    %% ── Step 4 : Inverse parity-switched global diffusion ───────────────────
    P9  = zeros(M, N, 3, 'uint8');
    P8d = double(P8);
    k   = 1;
    for ch = 1:3
        for i = 1:M
            for j = 1:N
                x1k = double(X1(k));  y1k = double(Y1(k));
                pix = P8d(i, j, ch);
                if mod(x1k + y1k, 2) == 0
                    val = mod(bitxor(uint32(abs(x1k - y1k)), ...
                              bitxor(uint32(pix), uint32(i))), 256);
                else
                    val = mod(bitxor(uint32(x1k + y1k), ...
                              bitxor(uint32(pix), uint32(i))), 256);
                end
                P9(i, j, ch) = uint8(val);
                k = k + 1;
            end
        end
    end

    %% ── Step 5 : Extract face region and reverse DNA diffusion ──────────────
    r  = F(2) : F(2)+F(4)-1;
    c  = F(1) : F(1)+F(3)-1;
    face_enc = P9(r, c, :);           % M0 x N0 x 3

    %  Reverse the XOR combination
    face_flat_enc = s_curve_flatten(face_enc);
    num_enc       = double(face_flat_enc);

    num_undone = uint8(mod( ...
        bitxor( bitxor(uint32(num_enc), ...
                       uint32(mod(double(Y0) .* double(X0), 256))), ...
                       uint32(mod(double(Z0) .* (1:nFace), 256)) ), ...
        256));

    %  Unflatten back to M0 x N0 x 3
    face_xor_removed = s_curve_unflatten(num_undone, M0, N0);

    %  Reverse DNA diffusion channel-wise
    face_recovered = dna_undiffuse_channels(face_xor_removed);

    %% ── Reconstruct full decrypted image ────────────────────────────────────
    P_dec       = P9;
    P_dec(r, c, :) = face_recovered;
    P_dec       = uint8(P_dec);
end
