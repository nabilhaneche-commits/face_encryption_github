function [X, Y, Z] = hyperchaotic_sequences(x0, y0, z0, n)
% HYPERCHAOTIC_SEQUENCES  Generates three quantized hyperchaotic sequences
%   of length N from the 4D ReLU-memristive hyperchaotic system.
%
%   [X, Y, Z] = HYPERCHAOTIC_SEQUENCES(x0, y0, z0, n)
%
%   Inputs
%   ------
%     x0, y0, z0 : scalar initial conditions derived from SHA-512
%     n           : number of samples to retain (integer)
%
%   Outputs
%   -------
%     X, Y, Z : 1-by-n uint32 arrays of quantized keystream values in [0,255]
%
%   The 4D system is:
%       dx1/dt = alpha*(x2 - x1)
%       dx2/dt = beta*x1 - eps*x1*x3
%       dx3/dt = -gamma*x3 + eps*x1^2 - delta*G(x4) + beta*x1
%       dx4/dt = delta*(x2 - x4)
%   where G(x4) is the ReLU-type memductance:
%       G(phi) = 1.5 + 3*min(max(phi,0),1)
%
%   Nominal parameters: alpha=3, beta=1, gamma=1, delta=1, eps=4
%   g_min=1.5, g_max=4.5, phi_sat=1
%   Initial condition for w: w0 = y0
%
%   The system is integrated with ode45 (step size dt=0.01).
%   The first 1000 transient samples are discarded.
%   The retained raw floating-point sequences are converted to uint32 in
%   [0,255] via:  uint32(mod(floor(abs(xi) * 1e14), 256))

    % ── System parameters ────────────────────────────────────────────────────
    alpha = 3;   beta  = 1;  gamma_p = 1;
    delta = 1;   eps_p = 4;
    g_min = 1.5; g_max = 4.5;

    % ReLU memductance
    G = @(phi) g_min + (g_max - g_min) .* min(max(phi, 0), 1);

    % ODE right-hand side
    ode = @(~, s) [ ...
        alpha  * (s(2) - s(1)); ...
        beta   *  s(1) - eps_p * s(1) * s(3); ...
       -gamma_p * s(3) + eps_p * s(1)^2 - delta * G(s(4)) + beta * s(1); ...
        delta  * (s(2) - s(4))  ];

    % ── Integration ──────────────────────────────────────────────────────────
    n_transient = 1000;
    n_total     = n + n_transient;
    dt          = 0.01;
    t_span      = linspace(0, n_total * dt, n_total + 1);

    s0  = [x0; y0; z0; y0];   % w0 = y0 as stated in the paper
    opt = odeset('RelTol', 1e-9, 'AbsTol', 1e-12);
    [~, S] = ode45(ode, t_span, s0, opt);

    % Discard transient, keep exactly n samples
    S = S(n_transient+2 : n_transient+1+n, :);  % n x 4

    % ── Quantization to [0,255] ───────────────────────────────────────────────
    quant = @(v) uint32(mod(floor(abs(v) * 1e14), 256));
    X = quant(S(:, 1))';   % 1 x n
    Y = quant(S(:, 2))';
    Z = quant(S(:, 3))';
end
