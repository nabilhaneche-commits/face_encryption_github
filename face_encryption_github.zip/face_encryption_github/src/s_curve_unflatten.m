function img = s_curve_unflatten(flat, M, N)
% S_CURVE_UNFLATTEN  Reconstructs a 3-channel image from a 1-D S-curve
%   serialized array.  Inverse of S_CURVE_FLATTEN.
%
%   img = S_CURVE_UNFLATTEN(flat, M, N)
%
%   flat : 1 x (3*M*N) uint8 row vector
%   M, N : spatial dimensions of the target image
%
%   Output : uint8 M x N x 3 image

    img = zeros(M, N, 3, 'uint8');
    ptr = 1;

    for ch = 1:3
        for i = 1:M
            row = flat(ptr : ptr+N-1);
            if mod(i, 2) == 1
                img(i, :, ch) = row;
            else
                img(i, end:-1:1, ch) = row;
            end
            ptr = ptr + N;
        end
    end
end
