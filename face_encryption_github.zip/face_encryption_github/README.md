# 4D ReLU-Memristive Hyperchaotic Face Image Encryption

> **Source code for the paper:**  
> Haneche N. and Hamaizia T., *"A novel 4D ReLU-memristive hyperchaotic system: Hidden attractors, multistability, and transient chaos with application to face recognition encryption,"* **The Visual Computer** (under review).

---

## Overview

This repository provides the complete MATLAB implementation of the face-targeted color image encryption algorithm presented in the paper. The scheme integrates:

- A **novel 4D ReLU-memristive hyperchaotic system** (hidden attractors, two positive Lyapunov exponents)
- **Haar cascade face detection** (MATLAB Computer Vision Toolbox) to confine intensive operations to the facial region
- **12-bit DNA diffusion** with Watson–Crick complementary base pairing (Rule 1)
- **Dual-layer global diffusion** using parity-switched XOR driven by coupled hyperchaotic sequences
- **Hyperchaotic Fisher–Yates permutation**
- **Inter-channel obfuscation** to eliminate residual RGB correlation

The face-targeted design reduces encryption time by **over 53%** compared to full-frame encryption while achieving information entropy above **7.99**, NPCR exceeding **99.60%**, and UACI around **33.41%**.

---

## Repository Structure

```
.
├── src/
│   ├── demo_encryption.m          % End-to-end demo (run this first)
│   ├── encrypt_image.m            % Main encryption function
│   ├── decrypt_image.m            % Main decryption function
│   ├── hyperchaotic_sequences.m   % 4D ODE system + keystream generation
│   ├── sha512_key_derive.m        % SHA-512 plaintext-dependent key derivation
│   ├── detect_face.m              % Haar cascade face detection wrapper
│   ├── dna_diffuse_channels.m     % 12-bit DNA diffusion (Rule 1) – forward
│   ├── dna_undiffuse_channels.m   % 12-bit DNA diffusion – inverse
│   ├── s_curve_flatten.m          % S-curve (boustrophedon) serializer
│   ├── s_curve_unflatten.m        % S-curve deserializer
│   ├── fisher_yates_scramble.m    % Hyperchaotic Fisher-Yates permutation
│   ├── fisher_yates_descramble.m  % Inverse permutation
│   ├── inter_channel_obfuscate.m  % Inter-channel mixing
│   └── inter_channel_deobfuscate.m% Inverse inter-channel mixing
├── data/
│   └── face_test.png              % Place your test face images here
├── results/                       % Encrypted/decrypted outputs are saved here
└── README.md
```

---

## Requirements

| Software | Version |
|---|---|
| MATLAB | R2021a or later |
| Image Processing Toolbox | any recent version |
| Computer Vision Toolbox | any recent version (Haar cascade) |
| Communications Toolbox | any recent version (`de2bi`, `bi2de`) |

> **Hardware used in the paper:** Intel Core i5-6300 @ 2.40 GHz, 16 GB RAM.

---

## Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/<your-username>/<repo-name>.git
   cd <repo-name>
   ```

2. **Place a face image** (256×256 RGB PNG or BMP) in the `data/` folder and name it `face_test.png`, or update the `IMAGE_PATH` variable in `demo_encryption.m`.

3. **Run the demo** in MATLAB:
   ```matlab
   cd src
   demo_encryption
   ```
   The script will print encryption/decryption times, security metrics (entropy, NPCR, UACI, pixel correlation), display the plaintext / ciphertext / decrypted image side-by-side, and save outputs to `results/`.

---

## The 4D Hyperchaotic System

The system is defined by:

```
dx1/dt =  alpha*(x2 - x1)
dx2/dt =  beta*x1 - eps*x1*x3
dx3/dt = -gamma*x3 + eps*x1^2 - delta*G(x4) + beta*x1
dx4/dt =  delta*(x2 - x4)
```

where the ReLU-type memductance is:

```
G(phi) = 1.5 + 3 * min(max(phi, 0), 1)
```

**Nominal parameters:** α = 3, β = 1, γ = 1, δ = 1, ε = 4  
**Lyapunov exponents:** LE₁ = 0.6283, LE₂ = 0.1231, LE₃ = −1.0008, LE₄ = −4.7482  
**Kaplan–Yorke dimension:** D_KY ≈ 2.7508

---

## Encryption Pipeline

```
Plaintext P
    │
    ├─► SHA-512 key derivation  ─►  x0,y0,z0  (face keys)
    │                           ─►  x1,y1,z1  (full-image keys)
    │
    ├─► Haar cascade face detection  ─►  P1 (face crop), F (bounding box)
    │
    ├─► Hyperchaotic sequences  ─►  X0,Y0,Z0  (face, len = 3·M0·N0)
    │                           ─►  X1,Y1,Z1  (full image, len = 3·M·N)
    │
    ├─► 12-bit DNA diffusion (Rule 1) on P1
    │
    ├─► S-curve flatten + XOR  ─►  P2(i) = num(i)⊕(Y0(i)×X0(i))⊕(Z0(i)×i)  mod 256
    │
    ├─► Reinsert P2 into full frame  ─►  P3
    │
    ├─► Parity-switched global diffusion  ─►  P4
    │
    ├─► Hyperchaotic Fisher-Yates permutation  ─►  P5
    │
    └─► Inter-channel obfuscation [R,G,B]→[B,R,G]  ─►  Ciphertext C
```

---

## Citation

If you use this code in your research, please cite:

```bibtex
@article{haneche2024relumemristive,
  title   = {A novel 4D ReLU-memristive hyperchaotic system: Hidden attractors,
             multistability, and transient chaos with application to face
             recognition encryption},
  author  = {Haneche, Nabil and Hamaizia, Tayeb},
  journal = {The Visual Computer},
  year    = {2024},
  note    = {Under review}
}
```

---

## Dataset

Test images were obtained from the publicly available Kaggle face dataset:  
<https://www.kaggle.com>

---

## License

This code is released for academic and research purposes. If you use or build upon it, please cite the paper above.

---

## Contact

**Haneche Nabil**  
Applied Mathematics and Modeling Laboratory  
Department of Mathematics, Constantine 1 University, Algeria  
📧 nabil.haneche@doc.umc.edu.dz
